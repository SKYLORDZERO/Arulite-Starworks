package data.hullmods;

import java.util.Iterator;
import java.util.List;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import org.magiclib.util.MagicIncompatibleHullmods;


public class arul_AdvancedPointDefenseAI extends BaseHullMod {

	public static final float DAMAGE_BONUS = 75f;

	//public static final float COST_INCREASE  = 2;

	@Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//stats.getRecoilPerShotMultSmallWeaponsOnly().modifyMult(id, 0f);
		//stats.getRecoilDecayMult().modifyMult(id, 10f);
		stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
		stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, 1f);
		stats.getDamageToMissiles().modifyPercent(id, DAMAGE_BONUS);
		//stats.getRecoilDecayMult().modifyMult(id, 2f);
//		stats.getDamageToMissiles().modifyPercent(id, DAMAGE_BONUS);
		stats.getDamageToFighters().modifyPercent(id, DAMAGE_BONUS);
		//stats.getProjectileSpeedMult().modifyMult(id, 100f);
		//stats.getWeaponTurnRateBonus().modifyMult(id, 2f);
		//stats.getDamageToFighters().modifyPercent(id, 50f);
		//stats.getProjectileSpeedMult().modifyPercent(id, 50f);
		//stats.getAutofireAimAccuracy().modifyFlat(id, 1f);

		//	List weapons = ship.getAllWeapons();
		//	Iterator iter = weapons.iterator();
		//	while (iter.hasNext()) {
		//		WeaponAPI weapon = (WeaponAPI) iter.next();
		//		if (weapon.hasAIHint(WeaponAPI.AIHints.PD)) {
		//			weapon.get;
		//		}
		//		boolean sizeMatches = weapon.getSize() == WeaponAPI.WeaponSize.SMALL;
		//		if (sizeMatches) stats.getDynamic().getMod(Stats.SMALL_BALLISTIC_MOD).modifyFlat(id, +COST_INCREASE);
		//		boolean sizeMatches = weapon.getSize() == WeaponAPI.WeaponSize.MEDIUM;
		//		if (sizeMatches) stats.getDynamic().getMod(Stats.MEDIUM_BALLISTIC_MOD).modifyFlat(id, +COST_INCREASE);
		//		boolean sizematches = weapon.getSize() == WeaponAPI.WeaponSize.LARGE;
		//		if (sizeMatches) stats.getDynamic().getMod(Stats.LARGE_BALLISTIC_MOD).modifyFlat(id, +COST_INCREASE);
		//	}

	}

	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {

		if (ship.getVariant().getHullMods().contains("pointdefenseai")) {
			MagicIncompatibleHullmods.removeHullmodWithWarning(ship.getVariant(),"pointdefenseai","arul_AdvancedPointDefenseAI");
		}

		List weapons = ship.getAllWeapons();
		Iterator iter = weapons.iterator();
		while (iter.hasNext()) {
			WeaponAPI weapon = (WeaponAPI)iter.next();
		//	if (weapon.AIHints() == PD) {
		//		weapon.get;
		//	}
		//	boolean sizeMatches = weapon.getSize() == WeaponSize.SMALL;
		//	boolean sizeMatches = weapon.getSize() == WeaponSize.MEDIUM;
		//	boolean sizematches = weapon.getSize() == WeaponSize.LARGE;

		//	if (sizeMatches && weapon.getType() != WeaponType.MISSILE) {
		//		weapon.setPD(true);
			}
		}

	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) DAMAGE_BONUS + "%"; // + (int) COST_REDUCTION + "";
		return null;
	}

	//I don't care if this part isn't necessary, i'm not removing it now in case it breaks
	public boolean isApplicableToShip(ShipAPI ship) {
		return !ship.getVariant().getHullMods().contains("pointdefenseai");
	}

	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().getHullMods().contains("pointdefenseai")) {
			return "Incompatible with Integrated Point Defense AI";
		}
		return null;
	}

}
	


//	public String getDescriptionParam(int index, HullSize hullSize) {
//		if (index == 0) return "" + (int)Math.round(DAMAGE_BONUS) + "%";
//		return null;
//	}

//}