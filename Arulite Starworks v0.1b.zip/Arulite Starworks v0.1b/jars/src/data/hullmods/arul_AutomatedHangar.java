package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.listeners.FighterOPCostModifier;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;

public class arul_AutomatedHangar extends BaseHullMod {

		@Override
		public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
			if (!stats.hasListenerOfClass(arul_AutomatedHangarListener.class)) {
				stats.addListener(new arul_AutomatedHangarListener());
			}
		}

		public static class arul_AutomatedHangarListener implements FighterOPCostModifier {
			@Override
			public int getFighterOPCost(MutableShipStatsAPI stats, FighterWingSpecAPI fighter, int currCost) {
				if (fighter.hasTag("auto_fighter")) return currCost;
				else return currCost + 10000;
			}
		}
	}